package interro1.musique;

import interro1.musique.data.*;

public class Disque {

    private Morceau[] lesMorceaux;
    private String titre;
    private int nbMorceauxGraves;

    public Disque(String titre, int nbMorceaux) {
	this.titre = titre;
	this.lesMorceaux = new Morceau[nbMorceaux];
	this.nbMorceauxGraves = 0;
    }

    public boolean estClos() {
	return this.nbMorceauxGraves == this.lesMorceaux.length;
    }

    public void graver(Morceau aGraver) throws DisqueClosException {
	if (this.estClos()) {
	    throw new DisqueClosException();
	}
	this.lesMorceaux[this.nbMorceauxGraves] = aGraver;
	this.nbMorceauxGraves = this.nbMorceauxGraves + 1; // NB : disque sera donc clos à la gravure du dernier 
    }
    
    public int dureeTotale() {
	if (! this.estClos()) {
	    return -1;
	}
	else  {
	    int duree = 0;
	    for (Morceau m : this.lesMorceaux) {
		duree = duree + m.getDuree();
	    }
	    return duree;
	}
    }
    
    public boolean equals(Object o) {
	if (o instanceof Disque) {
	    Disque lAutre = (Disque) o;
	    // clos tous les 2 ?
	    if (!this.estClos() || !lAutre.estClos()) {
		return false;
	    }
	    // même nombre de morceaux ?
	    if (this.lesMorceaux.length != lAutre.lesMorceaux.length) {
		return false;
	    }
	    // mêmes morceaux ? 
	    // on suppose qu'un morceau n'est gravé qu'une fois par disque
	    for(Morceau m : lAutre.lesMorceaux) {
		if (! this.contient(m)) {
		    return false;
		}
	    }
	    /* ou :
	    for(int i = 0; i < lAutre.lesMorceaux.length; i++) {
		if (! this.contient(lAutre.lesMorceaux[i])) {
		    return false;
		}
	    }
	     */
	    return true;
	}
	else {
	    return false;
	}
    }

    /** renvoie true ssi le morceau m a été gravé sur ce disque
     *  @param m le morceau testé
     *  @return true ssi le morceau m a été gravé sur ce disque
     */
    private boolean contient(Morceau morceau) {
	for(Morceau m : this.lesMorceaux) {
	    if (morceau.equals(m)) {
		return true;
	    }
	}
	return false;
    }

    public static void main(String[] args) {
	Morceau m1 = new Morceau("t1",30);
	Morceau m2 = new Morceau("t2",45);
	Disque d = new Disque("td",2);
	try {
	    d.graver(m1);
	    d.graver(m2);
	    System.out.println(d.dureeTotale());
	} catch(DisqueClosException e) {
	    e.printStackTrace();
	}	
    }

    /* Question 7
     * Q7.1
       /home/ie1/src > java interro1/musique/Disque.java -d ../classes
     * Q 7.2
       /home/ie1/classes > java interro1.musique.Disque
     * Q 7.3
       /home/ie1 > java -classpath classes interro1.musique.Disque
    */
}
