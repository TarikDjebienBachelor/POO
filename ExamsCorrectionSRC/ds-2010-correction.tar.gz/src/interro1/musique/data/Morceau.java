package interro1.musique.data;

public class Morceau {
    
    private String titre;
    private int duree;

    public Morceau(String titre, int duree) {
	this.titre = titre;
	this.duree = duree;
    }

    public int getDuree() {
	return this.duree;
    }

    public String getTitre() {
	return this.titre;
    }

    public boolean equals(Object o) {
	return true; // pour la compilation
    }
    public String toString() {
	return "...";  // pour la compilation
    }

}
