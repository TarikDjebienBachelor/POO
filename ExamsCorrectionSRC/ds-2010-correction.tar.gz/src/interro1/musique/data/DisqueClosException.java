package interro1.musique.data;

public class DisqueClosException extends Exception {
    public DisqueClosException() {
    }
}
