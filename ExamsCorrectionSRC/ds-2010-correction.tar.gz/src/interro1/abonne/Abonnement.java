package interro1.abonne;

import interro1.util.Date;

public class Abonnement {

    private String abonne;
    private Date date;
    private Categorie categorie;

    public Abonnement(String nomAbonne) {
	this.abonne = nomAbonne;
	this.date = Date.aujourdhui();
	this.categorie = Categorie.bronze;
    }

    public String getAbonne() {
	return this.abonne;
    }
    public Date getDate() {
	return this.date;
    }
    public Categorie getCategorie() {
	return this.categorie;
    }
    public void setCategorie(Categorie categorie) {
	this.categorie = categorie;
    }

    public String toString() {
	return "l'abonne "+this.abonne+", date abonnement :"+this.date+
	    ", categorie abonnement : "+this.categorie;
    }
    
    public boolean equals(Object o) {
	if (o instanceof Abonnement) {
	    Abonnement lAutre = (Abonnement) o;
	    return this.abonne.equals(lAutre.abonne) 
		&& this.date.equals(lAutre.date) 
		&& this.categorie == lAutre.categorie; // ou this.categorie.equals(lAutre.categorie);
	    }
	else {
	    return false;
	}
    }

}
