package interro1.abonne;

public enum Categorie {
    bronze, argent, or;
}
