package interro1.util;

public class Date {

    public static Date aujourdhui() {
	return null; // pour la compilation
    }
    public boolean equals(Object o) {
	return true; // pour la compilation
    }
    public String toString() {
	return "...";  // pour la compilation
    }

}
