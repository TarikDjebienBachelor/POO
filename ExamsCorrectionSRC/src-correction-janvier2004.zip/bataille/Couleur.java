/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Couleur {

	private String name;

		private Couleur(String name) {
			this.name = name;
		}
	
		public static Couleur COEUR = new Couleur("Coeur");
		public static Couleur CARREAU = new Couleur("Carreau");
		public static Couleur TREFLE = new Couleur("Trefle");
		public static Couleur PIQUE = new Couleur("Pique");

		public String toString() {
			return this.name;
		}
}
