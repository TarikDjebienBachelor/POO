/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Carte implements Comparable {

	private Couleur couleur;
	private Valeur valeur;
	
	public Carte(Couleur c, Valeur v) {
		this.couleur = c;
		this.valeur = v;
	}
	
	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		return this.valeur.compareTo(((Carte) o).valeur);
	}

	/**
	 * @return
	 */
	public Couleur getCouleur() {
		return this.couleur;
	}

	/**
	 * @return
	 */
	public Valeur getValeur() {
		return this.valeur;
	}

	/**
	 * @param couleur
	 */
	public void setCouleur(Couleur couleur) {
		this.couleur = couleur;
	}

	/**
	 * @param valeur
	 */
	public void setValeur(Valeur valeur) {
		this.valeur = valeur;
	}
	
	public String toString() {
		return this.valeur+" de "+this.couleur;
	}

}
