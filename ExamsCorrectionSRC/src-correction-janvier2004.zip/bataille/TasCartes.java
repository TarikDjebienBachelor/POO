/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

import java.util.*;

/** Gere un tas de cartes
 * 
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class TasCartes {
	
	private LinkedList lesCartes;
	
	public TasCartes() {
		this.lesCartes = new LinkedList();
	}

	/*
	 * enleve en tete 
	 */
	 public Carte enleveCarteEnTete() {
		return (Carte) this.lesCartes.removeFirst();
	}
	/*
	 * enleve en tete 
	 */
	 public Carte enleveCarteEnFin() {
		return (Carte) this.lesCartes.removeFirst();
	}
	
	/**
	 * ajoute en fin
	 * @param carte
	 */
	public void ajouteCarteEnFin(Carte carte) {
		this.lesCartes.addLast(carte);
	}
	
	public void ajouteDesCartesEnFin(TasCartes tas) {
		for(Iterator carte_it = tas.lesCartes.iterator(); carte_it.hasNext(); ) {
			this.ajouteCarteEnFin((Carte) carte_it.next());
		}
	}
	/**
	 * ajoute en tete
	 * @param carte
	 */
	public void ajouteCarteEnTete(Carte carte) {
		this.lesCartes.addFirst(carte);
	}
	
	public void ajouteDesCartesEnTete(TasCartes tas) {
		for(Iterator carte_it = tas.lesCartes.iterator(); carte_it.hasNext(); ) {
			this.ajouteCarteEnTete((Carte) carte_it.next());
		}
	}
	
	public boolean estVide() {
		return this.lesCartes.isEmpty();
	}
}
