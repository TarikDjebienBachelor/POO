/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Bataille {

	private TasCartes[] tas;
	private TasCartes tas2;

	private TasCartes table;

	public Bataille() {
		this.table = new TasCartes();

		this.tas = new TasCartes[2];
		this.tas[0] = new TasCartes();
		this.tas[1] = new TasCartes();

		this.initTas();
	}

	private void initTas() {
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.NEUF));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.DAME));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.COEUR, Valeur.AS));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.TREFLE, Valeur.VALET));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.SEPT));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.PIQUE, Valeur.VALET));

		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.VALET));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.SEPT));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.COEUR, Valeur.AS));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.TREFLE, Valeur.NEUF));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.DAME));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.PIQUE, Valeur.VALET));

	}

	public boolean estFinie() {
		return this.tas[0].estVide() || this.tas[1].estVide();
	}

	private void joueurRamasse(int numJoueur) {
		System.out.println("joueur " + (numJoueur + 1) + " gagne \n");
		// on "enfile" les tas
		this.tas[numJoueur].ajouteDesCartesEnFin(table);
		// et vide ce qui est sur la table
		table = new TasCartes();
	}

	private Carte joueurPose(int numJoueur) {
		Carte carte = this.tas[numJoueur].enleveCarteEnTete();
		table.ajouteCarteEnTete(carte);
		System.out.println("joueur " + (numJoueur + 1) + " pose " + carte);
		return carte;
	}

	public void joue() {
		Carte carte1;
		Carte carte2;

		int compareCartes;

		TasCartes table = new TasCartes(); // les tas sur la table du joueur 1 (en fait on s'en sert comme d'une pile)

		while (!this.estFinie()) {
			carte1 = this.joueurPose(0);
			carte2 = this.joueurPose(1);
		
			compareCartes = carte1.compareTo(carte2);
			if (compareCartes == 0) {
				// BATAILLE : chaque joueur pose une carte sur la table et on continue
				System.out.println(" !!!!!!!! Bataille !!!!!! ");
				this.joueurPose(0);
				this.joueurPose(1);
				System.out.println();
				
			}
			else if (compareCartes < 0) {

				//			joueur2 gagne et empoche les 2 tas sur la table
				this.joueurRamasse(1);
			}
			else {
				//			joueur1 gagne et empoche les 2 tas sur la table
				this.joueurRamasse(0);
			}
		}
		if (tas[0].estVide()) {
			System.out.println("le joueur 2 gagne");
		}
		else {
			System.out.println("le joueur 1 gagne");
		}
	}

	public static void main(String[] args) {
		new Bataille().joue();
	}
}
/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Carte implements Comparable {

	private Couleur couleur;
	private Valeur valeur;
	
	public Carte(Couleur c, Valeur v) {
		this.couleur = c;
		this.valeur = v;
	}
	
	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		return this.valeur.compareTo(((Carte) o).valeur);
	}

	/**
	 * @return
	 */
	public Couleur getCouleur() {
		return this.couleur;
	}

	/**
	 * @return
	 */
	public Valeur getValeur() {
		return this.valeur;
	}

	/**
	 * @param couleur
	 */
	public void setCouleur(Couleur couleur) {
		this.couleur = couleur;
	}

	/**
	 * @param valeur
	 */
	public void setValeur(Valeur valeur) {
		this.valeur = valeur;
	}
	
	public String toString() {
		return this.valeur+" de "+this.couleur;
	}

}
/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Couleur {

	private String name;

		private Couleur(String name) {
			this.name = name;
		}
	
		public static Couleur COEUR = new Couleur("Coeur");
		public static Couleur CARREAU = new Couleur("Carreau");
		public static Couleur TREFLE = new Couleur("Trefle");
		public static Couleur PIQUE = new Couleur("Pique");

		public String toString() {
			return this.name;
		}
}
/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

import java.util.*;

/** Gere un tas de cartes
 * 
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class TasCartes {
	
	private LinkedList lesCartes;
	
	public TasCartes() {
		this.lesCartes = new LinkedList();
	}

	/*
	 * enleve en tete 
	 */
	 public Carte enleveCarteEnTete() {
		return (Carte) this.lesCartes.removeFirst();
	}
	/*
	 * enleve en tete 
	 */
	 public Carte enleveCarteEnFin() {
		return (Carte) this.lesCartes.removeFirst();
	}
	
	/**
	 * ajoute en fin
	 * @param carte
	 */
	public void ajouteCarteEnFin(Carte carte) {
		this.lesCartes.addLast(carte);
	}
	
	public void ajouteDesCartesEnFin(TasCartes tas) {
		for(Iterator carte_it = tas.lesCartes.iterator(); carte_it.hasNext(); ) {
			this.ajouteCarteEnFin((Carte) carte_it.next());
		}
	}
	/**
	 * ajoute en tete
	 * @param carte
	 */
	public void ajouteCarteEnTete(Carte carte) {
		this.lesCartes.addFirst(carte);
	}
	
	public void ajouteDesCartesEnTete(TasCartes tas) {
		for(Iterator carte_it = tas.lesCartes.iterator(); carte_it.hasNext(); ) {
			this.ajouteCarteEnTete((Carte) carte_it.next());
		}
	}
	
	public boolean estVide() {
		return this.lesCartes.isEmpty();
	}
}
/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Valeur implements Comparable {

	private String name;
	private static int cpt = 0;
	private final int index;

	private Valeur(String name) {
		this.name = name;
		this.index = cpt++;
	}

	public static Valeur AS = new Valeur("As");
	public static Valeur ROI = new Valeur("Roi");
	public static Valeur DAME = new Valeur("Dame");
	public static Valeur VALET = new Valeur("Valet");
	public static Valeur DIX = new Valeur("10");
	public static Valeur NEUF = new Valeur("9");
	public static Valeur HUIT = new Valeur("8");
	public static Valeur SEPT = new Valeur("7");

	public String toString() {
		return this.name;
	}
	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		return ((Valeur) o).index - this.index;
	}

}
