/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Bataille {

	private TasCartes[] tas;
	private TasCartes tas2;

	private TasCartes table;

	public Bataille() {
		this.table = new TasCartes();

		this.tas = new TasCartes[2];
		this.tas[0] = new TasCartes();
		this.tas[1] = new TasCartes();

		this.initTas();
	}

	private void initTas() {
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.NEUF));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.DAME));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.COEUR, Valeur.AS));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.TREFLE, Valeur.VALET));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.SEPT));
		this.tas[0].ajouteCarteEnTete(new Carte(Couleur.PIQUE, Valeur.VALET));

		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.VALET));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.SEPT));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.COEUR, Valeur.AS));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.TREFLE, Valeur.NEUF));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.CARREAU, Valeur.DAME));
		this.tas[1].ajouteCarteEnTete(new Carte(Couleur.PIQUE, Valeur.VALET));

	}

	public boolean estFinie() {
		return this.tas[0].estVide() || this.tas[1].estVide();
	}

	private void joueurRamasse(int numJoueur) {
		System.out.println("joueur " + (numJoueur + 1) + " gagne \n");
		// on "enfile" les tas
		this.tas[numJoueur].ajouteDesCartesEnFin(table);
		// et vide ce qui est sur la table
		table = new TasCartes();
	}

	private Carte joueurPose(int numJoueur) {
		Carte carte = this.tas[numJoueur].enleveCarteEnTete();
		table.ajouteCarteEnTete(carte);
		System.out.println("joueur " + (numJoueur + 1) + " pose " + carte);
		return carte;
	}

	public void joue() {
		Carte carte1;
		Carte carte2;

		int compareCartes;

		TasCartes table = new TasCartes(); // les tas sur la table du joueur 1 (en fait on s'en sert comme d'une pile)

		while (!this.estFinie()) {
			carte1 = this.joueurPose(0);
			carte2 = this.joueurPose(1);
		
			compareCartes = carte1.compareTo(carte2);
			if (compareCartes == 0) {
				// BATAILLE : chaque joueur pose une carte sur la table et on continue
				System.out.println(" !!!!!!!! Bataille !!!!!! ");
				if (! this.estFinie()) { // les 2 joueurs ont encore des cartes ?
				    this.joueurPose(0);
				    this.joueurPose(1);
				    System.out.println();
				}
				
			}
			else if (compareCartes < 0) {

				//			joueur2 gagne et empoche les 2 tas sur la table
				this.joueurRamasse(1);
			}
			else {
				//			joueur1 gagne et empoche les 2 tas sur la table
				this.joueurRamasse(0);
			}
		}
		if (tas[0].estVide()) {
			System.out.println("le joueur 2 gagne");
		}
		else {
			System.out.println("le joueur 1 gagne");
		}
	}

	public static void main(String[] args) {
		new Bataille().joue();
	}
}
