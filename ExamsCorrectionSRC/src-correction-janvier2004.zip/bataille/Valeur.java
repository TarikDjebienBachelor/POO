/*
 * Created on 16 janv. 2004
 *
 */
package bataille;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Valeur implements Comparable {

	private String name;
	private static int cpt = 0;
	private final int index;

	private Valeur(String name) {
		this.name = name;
		this.index = cpt++;
	}

	public static Valeur AS = new Valeur("As");
	public static Valeur ROI = new Valeur("Roi");
	public static Valeur DAME = new Valeur("Dame");
	public static Valeur VALET = new Valeur("Valet");
	public static Valeur DIX = new Valeur("10");
	public static Valeur NEUF = new Valeur("9");
	public static Valeur HUIT = new Valeur("8");
	public static Valeur SEPT = new Valeur("7");

	public String toString() {
		return this.name;
	}
	/**
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		return ((Valeur) o).index - this.index;
	}

}
