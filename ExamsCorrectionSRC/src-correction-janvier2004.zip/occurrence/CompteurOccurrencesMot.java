/*
 * Created on 12 janv. 2004
 *
 */
package occurrence;

import java.util.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class CompteurOccurrencesMot implements CompteurOccurrences {

	/**
	 * @see occurrence.CompteurOccurrences#calculOccurrences(occurrence.Texte)
	 */
	public Map calculOccurrences(Texte txt) {
		Map res = new HashMap();
		StringTokenizer st = new StringTokenizer(txt.getLeTexte(), "., ;:!?", false);
		while (st.hasMoreTokens()) {
			String token = st.nextToken();
			if (res.containsKey(token)) {
				res.put(token, new Integer(((Integer) res.get(token)).intValue() + 1));
			}
			else {
				res.put(token, new Integer(1));
			}
		}
		return res;
	}

}
