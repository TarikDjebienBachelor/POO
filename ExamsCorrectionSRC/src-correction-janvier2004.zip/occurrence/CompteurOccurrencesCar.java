/*
 * Created on 12 janv. 2004
 *
 */
package occurrence;

import java.util.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class CompteurOccurrencesCar implements CompteurOccurrences {

	/**
	 * @see occurrence.CompteurOccurrences#calculOccurrences(occurrence.Texte)
	 */
	public Map calculOccurrences(Texte txt) {
		Map res = new HashMap();
		int l = txt.getLeTexte().length();
		for (int i = 0; i < l; i++) {
			Character c = new Character(txt.getLeTexte().charAt(i));
			// si le car est d�j� r�pertori� on incr�mente son nb occ
			if (res.containsKey(c)) {
				res.put(c, new Integer(((Integer) res.get(c)).intValue() + 1));
			}
			else { // sinon on r�pertorie le caractere
				res.put(c, new Integer(1));
			}
		}
		return res;
	}

}
