/*
 * Created on 12 janv. 2004
 *
 */
package occurrence;
import java.util.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public interface CompteurOccurrences {
	public Map calculOccurrences(Texte t);
}
