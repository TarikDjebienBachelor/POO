/*
 * Created on 12 janv. 2004
 *
 */
package occurrence;
import java.util.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Texte {

	private String leTexte;
	public Texte(String texte) {
		this.leTexte = texte;
	}
	public String getLeTexte() {
		return leTexte;
	}
	public void afficheOccurrences(CompteurOccurrences cpteurOcc) {
		Map m = cpteurOcc.calculOccurrences(this);
		Iterator itOcc = m.keySet().iterator();
		while (itOcc.hasNext()) {
			Object o = itOcc.next();
			System.out.println(o.toString() + " : " + ((Integer) m.get(o)).intValue());
		}
	}

	public static void main(String[] args) {
		Texte txt =
			new Texte("L'ain� de ceux-ci et le favori de Bilbon �tait le jeune Frodon Sacquet. A quatre-vingt-dix-neuf ans, Bilbon l'adopta comme h�ritier; il l'amena vivre � Cul-de-Sac, et les esp�rances des Sacquet de Besace furent d�finitivement an�anties. Bilbon et Frodon se trouvaient avoir le m�me anniversaire: le 22 septembre. 'Tu ferais mieux de venir habiter ici, Frodon, mon gars, dit un jour Bilbon; nous pourrons ainsi c�l�brer confortablement notre anniversaire ensemble.' A cette �poque, Frodon �tait encore dans ses ann�es interm�diaires, comme les Hobbits appelaient les ann�es d'irresponsabilit� qui s'�tendaient entre l'enfance et la majorit� � trente-trois ans.");
				
		txt.afficheOccurrences(new CompteurOccurrencesCar());
		txt.afficheOccurrences(new CompteurOccurrencesMot());
	}
}
