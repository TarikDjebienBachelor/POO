/*
 * Created on 12 janv. 2004
 *
 */
package agence;

import java.util.*;
/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class InterCritere implements Critere {

	private List sesCriteres;

	// creation d'un ensemble de crit�res vide
	public InterCritere() {
		this.sesCriteres = new ArrayList();
	}

	public List criteres() {
		return this.sesCriteres;
	}

	/* Ajout d'un crit�re
	 * @param c le crit�re ajout�
	 */
	public void ajoutCritere(Critere c) {
		this.criteres().add(c);
	}

	public boolean correspond(Object o) {
		Iterator it = this.criteres().iterator();
		while (it.hasNext()) {
			if (!((Critere) it.next()).correspond(o)) {
				return false;
			}
		}
		return true;
	}
}