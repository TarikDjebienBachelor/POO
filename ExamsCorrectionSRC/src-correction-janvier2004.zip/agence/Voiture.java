/*
 * Created on 12 janv. 2004
 *
 */
package agence;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Voiture {
	//sa marque
	private final String saMarque;
	// son modele
	private final String sonModele;
	// son ann�e de production
	private final int sonAnnee;
	// son prix de location / jour
	private final int sonPrix;

	/** Constructeur initialisant coml�tement cette voiture.
		* @param ma marque
		* @param mo modele
		* @param a annee de production
		* @param p prix de location / jour
		*/
	public Voiture(String ma, String mo, int a, int p) {
		this.saMarque = ma;
		this.sonModele = mo;
		this.sonAnnee = a;
		this.sonPrix = p;
	}

	public String marque() {
		return this.saMarque;
	}

	public String modele() {
		return this.sonModele;
	}

	public int annee() {
		return this.sonAnnee;
	}

	public int prixLocation() {
		return this.sonPrix;
	}

	public boolean equals(Object o) {
		try {
			Voiture v = (Voiture) o;
			return (v.marque().equals(this.marque()) && v.modele().equals(this.modele()) && v.annee() == this.annee() && v.prixLocation() == this.prixLocation());
			}
		catch (ClassCastException e) {
			return false;
		}
	}
}