/*
 * Created on 12 janv. 2004
 *
 */
package agence;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class CriterePrix implements Critere {
	private int prix;

	/** @param p prix */
	public CriterePrix(int p) {
		this.prix = p;
	}

	public boolean correspond(Object o) {
		if (! (o instanceof Voiture)) {
			return false;
		}
		return ((Voiture) o).prixLocation() <= this.prix;
	}

}
