/*
 * Created on 12 janv. 2004
 *
 */
package agence;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public interface Critere {
	/** @return true si et seulement si l'objet o est conforme au
	 * crit�re (on dit que o satisfait le crit�re)
	*/
	public boolean correspond(Object o);
}
