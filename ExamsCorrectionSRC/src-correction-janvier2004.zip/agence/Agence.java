/*
 * Created on 12 janv. 2004
 *
 */
package agence;

import java.util.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Agence {

	private List voitures = new ArrayList();

	public List selectionne(Critere c) {

		List result = new ArrayList();
		Iterator it = this.voitures.iterator();
		while (it.hasNext()) {
			Voiture v = (Voiture) it.next();
			if (c.correspond(v))
				result.add(v);
		}
		return result;
	}

	public static void main(String[] args) {
		Agence agence = new Agence();
		agence.selectionne(new CriterePrix(100));

		InterCritere ic = new InterCritere();
		ic.ajoutCritere(new CriterePrix(100));
		ic.ajoutCritere(new CritereMarque("Timol�on"));
		
		agence.selectionne(ic);
	}

}
