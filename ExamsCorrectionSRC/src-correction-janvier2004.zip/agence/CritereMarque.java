/*
 * Created on 12 janv. 2004
 *
 */
package agence;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class CritereMarque implements Critere {
	// marque des voitures correspondant au crit�re
	private String marque;

	/** @param m marque */
	public CritereMarque(String m) {
		this.marque = m;
	}

	public boolean correspond(Object o) {
		if (!(o instanceof Voiture)) {
			return false;
		}
		Voiture v = (Voiture) o;
		return v.marque().equals(this.marque);
	}
}
