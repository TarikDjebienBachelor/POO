/*
 * Created on 12 janv. 2004
 *
 */
package agence;

import java.util.*;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Agence {

	private List voitures = new ArrayList();

	public List selectionne(Critere c) {

		List result = new ArrayList();
		Iterator it = this.voitures.iterator();
		while (it.hasNext()) {
			Voiture v = (Voiture) it.next();
			if (c.correspond(v))
				result.add(v);
		}
		return result;
	}

	public static void main(String[] args) {
		Agence agence = new Agence();
		agence.selectionne(new CriterePrix(100));

		InterCritere ic = new InterCritere();
		ic.ajoutCritere(new CriterePrix(100));
		ic.ajoutCritere(new CritereMarque("Timol�on"));
		
		agence.selectionne(ic);
	}

}
/*
 * Created on 12 janv. 2004
 *
 */
package agence;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public interface Critere {
	/** @return true si et seulement si l'objet o est conforme au
	 * crit�re (on dit que o satisfait le crit�re)
	*/
	public boolean correspond(Object o);
}
/*
 * Created on 12 janv. 2004
 *
 */
package agence;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class CritereMarque implements Critere {
	// marque des voitures correspondant au crit�re
	private String marque;

	/** @param m marque */
	public CritereMarque(String m) {
		this.marque = m;
	}

	public boolean correspond(Object o) {
		if (!(o instanceof Voiture)) {
			return false;
		}
		Voiture v = (Voiture) o;
		return v.marque().equals(this.marque);
	}
}
/*
 * Created on 12 janv. 2004
 *
 */
package agence;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class CriterePrix implements Critere {
	private int prix;

	/** @param p prix */
	public CriterePrix(int p) {
		this.prix = p;
	}

	public boolean correspond(Object o) {
		if (! (o instanceof Voiture)) {
			return false;
		}
		return ((Voiture) o).prixLocation() <= this.prix;
	}

}
/*
 * Created on 12 janv. 2004
 *
 */
package agence;

import java.util.*;
/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class InterCritere implements Critere {

	private List sesCriteres;

	// creation d'un ensemble de crit�res vide
	public InterCritere() {
		this.sesCriteres = new ArrayList();
	}

	public List criteres() {
		return this.sesCriteres;
	}

	/* Ajout d'un crit�re
	 * @param c le crit�re ajout�
	 */
	public void ajoutCritere(Critere c) {
		this.criteres().add(c);
	}

	public boolean correspond(Object o) {
		Iterator it = this.criteres().iterator();
		while (it.hasNext()) {
			if (!((Critere) it.next()).correspond(o)) {
				return false;
			}
		}
		return true;
	}
}/*
 * Created on 12 janv. 2004
 *
 */
package agence;

/**
 * @author <a href="mailto:routier@lifl.fr">JC Routier</a>
 *
 */
public class Voiture {
	//sa marque
	private final String saMarque;
	// son modele
	private final String sonModele;
	// son ann�e de production
	private final int sonAnnee;
	// son prix de location / jour
	private final int sonPrix;

	/** Constructeur initialisant coml�tement cette voiture.
		* @param ma marque
		* @param mo modele
		* @param a annee de production
		* @param p prix de location / jour
		*/
	public Voiture(String ma, String mo, int a, int p) {
		this.saMarque = ma;
		this.sonModele = mo;
		this.sonAnnee = a;
		this.sonPrix = p;
	}

	public String marque() {
		return this.saMarque;
	}

	public String modele() {
		return this.sonModele;
	}

	public int annee() {
		return this.sonAnnee;
	}

	public int prixLocation() {
		return this.sonPrix;
	}

	public boolean equals(Object o) {
		try {
			Voiture v = (Voiture) o;
			return (v.marque().equals(this.marque()) && v.modele().equals(this.modele()) && v.annee() == this.annee() && v.prixLocation() == this.prixLocation());
			}
		catch (ClassCastException e) {
			return false;
		}
	}
}