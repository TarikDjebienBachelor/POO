package cryptage;

// Chaque algo de cryptage impl�mente AlgoCryptage
public class Algo3 implements AlgoCryptage {


	public Message decrypte(Message m) {
		// TODO Auto-generated method stub
		return null;
	}

}
