package cryptage;

public interface AlgoCryptage {
	public Message decrypte(Message m);
}
