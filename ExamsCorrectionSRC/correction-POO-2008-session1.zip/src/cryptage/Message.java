package cryptage;

public interface Message {
	public boolean estCrypte();
}
