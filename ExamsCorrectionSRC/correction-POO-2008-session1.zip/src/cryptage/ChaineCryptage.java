package cryptage;

import java.util.*;

// Chaine de cryptage est un algo de cryptage et donc impl�mente AlgoCryptage
public class ChaineCryptage implements AlgoCryptage {

	private List<AlgoCryptage> lesAlgos;
	
	public ChaineCryptage() {
		this.lesAlgos = new ArrayList<AlgoCryptage>();
	}

	public void addAlgo(AlgoCryptage algo) { 
		this.lesAlgos.add(algo);
	}
	
	public Message decrypte(Message m) {
		boolean decrypte = false;		
		Iterator<AlgoCryptage> it_algo = this.lesAlgos.iterator();
		Message msg = m;
		while (msg.estCrypte() && it_algo.hasNext()) {
			msg = it_algo.next().decrypte(m);			
		}
		if (msg.estCrypte()) {
			return null;
		} else {
			return msg;
		}
	}

}
