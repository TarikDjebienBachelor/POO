package parc;

// Reponse Question 5



/**
 * Condition toujours fqusse permettant d exprimer qu une attraction est en maintenance
 */

public class ConditionMaintenance implements ConditionAcces {

	public boolean accesPossible(Personne p) {	
		return false;
	}

	@Override
	public String getDescription() {
		return "En maintenance -- Acces impossible";
	}

}
