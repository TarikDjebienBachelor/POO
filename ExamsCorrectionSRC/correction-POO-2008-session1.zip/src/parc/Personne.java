package parc;

public class Personne {
	private String nom;
	private int age;
	private int taille;
	
	public Personne(String nom, int age, int taille) {
		this.nom = nom;
		this.age = age;
		this.taille = taille;
	}

	public String getNom() {
		return nom;
	}

	public int getAge() {
		return age;
	}

	public int getTaille() {
		return taille;
	}
	
	public boolean equals(Object o) {
		// � compl�ter
		return false;
	}
	
	public int hashCode() {
		// � compl�ter
		return 0;
	}
	
	public String toString() {
		// � compl�ter
		return "";
	}
	
}
