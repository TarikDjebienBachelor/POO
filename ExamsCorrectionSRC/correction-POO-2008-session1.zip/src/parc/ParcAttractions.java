package parc;

import java.util.List;

public class ParcAttractions {

	public static final float PRIX_TICKET = 1.5f;
	private List<Attraction> lesAttractions;
	private String nom;
	
	public ParcAttractions(String nom) {
		this.nom = nom;
	}
	
	public void ajouteAttraction(Attraction att) {
		this.lesAttractions.add(att);
	}
	
	public float getRecette() {
		float result = 0;
		for (Attraction att : this.lesAttractions) {
			result = result + att.getRecette();
		}
		return result;
	}
	
	public void affichage() {
		System.out.println("Parc : "+this.nom);
		for(Attraction att : this.lesAttractions) {
			System.out.println("Attraction "+att.getNom()+" "+att.getCondition()+" "+att.getRecette());
		}
	}
}
