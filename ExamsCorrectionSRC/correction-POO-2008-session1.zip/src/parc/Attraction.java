package parc;

public class Attraction {

	private ConditionAcces condition;
	private int cout;
	private float recette;
	private int nbVisiteurs;
	private String nom;
	
	public Attraction(String nom, int cout, ConditionAcces condition) {
		this.nom = nom;
		this.condition = condition;
		this.cout = cout;
		this.recette = 0;
		this.nbVisiteurs = 0;		
	}
	
	public float getRecette() {
		return this.recette;
	}
	
	public int getNbVisiteurs() {
		return this.nbVisiteurs;
	}
	
	public void utilise(Personne p, MoyenPaiement m) throws AccesInterditException {
		if (! this.condition.accesPossible(p)) {
			throw new AccesInterditException();
		}
		this.nbVisiteurs = this.nbVisiteurs +1;
		if (m == MoyenPaiement.euro) {
			this.recette = this.recette + cout;
		} else {
			this.recette  = this.recette + ParcAttractions.PRIX_TICKET;
		}
	}

	public ConditionAcces getCondition() {
		return condition;
	}

	public void setCondition(ConditionAcces condition) {
		this.condition = condition;
	}

	public String getNom() {
		return nom;
	}
	
}
