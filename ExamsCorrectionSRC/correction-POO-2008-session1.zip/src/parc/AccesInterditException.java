package parc;

public class AccesInterditException extends Exception {

}
