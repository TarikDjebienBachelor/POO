package parc;

public interface ConditionAcces {
	public boolean accesPossible(Personne p);
	public String getDescription();
}
