package parc;

public enum MoyenPaiement {
	euro,ticket;
}
