package parc;

public class ConditionAge implements ConditionAcces {

	private int ageLimite;
	
	public ConditionAge(int age) {
		this.ageLimite = age;
	}

	public boolean accesPossible(Personne p) {
		return p.getAge() >= this.ageLimite;
	}


	public String getDescription() {		
		return "age limite accepte : "+this.ageLimite;
	}

}
