package ecommerce;

public enum StatutCommande {
	encours, expediee, livree;
}
