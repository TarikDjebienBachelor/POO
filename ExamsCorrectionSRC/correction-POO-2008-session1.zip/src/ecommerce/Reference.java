package ecommerce;

public class Reference {

	private String label;
	
	public String getLabel() {
		return label;
	}

	public Reference(String label) {
		this.label = label;
	}
	
	public boolean equals(Object obj) {
		if (obj instanceof Reference) {
			Reference lAutre = (Reference) obj;
			return lAutre.label.equals(this.label);
		} 
		else {
			return false;
		}
	}

	public int hashCode() {		
		return this.label.hashCode();
	}

	public String toString() {		
		return this.label;
	}

}
