package ecommerce;

public class Article {

	//...
	
	public String toString() {
		// ...
		return "";
	}
	
}
