package ecommerce;

public class Catalogue {

	public Article getArticle(Reference ref) throws ReferenceInconnueException {
		// ...
		return null;
	}
	
	public int getPrixHT(Reference ref)  throws ReferenceInconnueException {
		// ...
		return 0;
	}
	
}
