package ecommerce;

public class CommandeValideeException extends Exception {

}
