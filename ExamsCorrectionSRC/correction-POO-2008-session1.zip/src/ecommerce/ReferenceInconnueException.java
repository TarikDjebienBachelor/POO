package ecommerce;

public class ReferenceInconnueException extends RuntimeException {

}
