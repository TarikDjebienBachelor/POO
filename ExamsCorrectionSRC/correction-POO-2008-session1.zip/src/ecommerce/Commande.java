package ecommerce;

import java.util.*;

public class Commande {

	private Map<Reference, Integer> lesArticles;
	private StatutCommande statut;
	private Catalogue catalogue;
	private String numClient;

	// reponse Q 4 : num�ro unique 
	private static int cpt = 0;
	private int numero;
	
	
	/**
	 * cr�e une commande, initialement sans article
	 * 
	 * @param cata
	 *            le catalogue dont d�pend la commande
	 * @param numClient
	 *            le num�ro du client qui passe la commande
	 */
	public Commande(Catalogue cata, String numClient) {
		this.catalogue = cata;
		this.numClient = numClient;
		this.statut = StatutCommande.encours;
		this.lesArticles = new HashMap<Reference, Integer>();
		// r�ponse Q4 : 
		this.numero = Commande.cpt++;
	}

	/**
	 * modifie pour cette commande de qte} la quantit� d'articles dont la
	 * r�f�rence est reference}. Cette op�ration n'est possible que quand la
	 * commande a pour statut "en cours}". Si l'article n'�tait pas encore
	 * pr�sent dans la commande, il est ajout�. Si la quantit� dans la commande
	 * devient n�gative, l'article est supprim� de la commande.
	 * 
	 * @param reference
	 *            la r�f�rence de l'article concern�
	 * @param qte
	 *            la quantit� d'articles � prendre en compte (ajout si >0,
	 *            retrait si <0)
	 * @exception CommandeExpedieeException
	 *                si la commande n'est pas "en cours".
	 * @exception ReferenceInconnueException
	 *                si la r�f�rence n'existe pas dans le catalogue.
	 */
	public void modifieQuantite(Reference reference, int qte) throws CommandeValideeException, ReferenceInconnueException {
		if (this.statut != StatutCommande.encours) {
			throw new CommandeValideeException();
		}
		// l�ve une exception si r�f�rence inconnue
		this.catalogue.getArticle(reference);
		// la qte dans la commande, initialis�e � la valeur du param�tre
		int qteCommande = qte;
		if (this.lesArticles.containsKey(reference)) {
			qteCommande = qte + this.lesArticles.get(reference);
		}
		if (qteCommande <= 0) {
			this.lesArticles.remove(reference);
		} else {
			this.lesArticles.put(reference, qteCommande);
		}

	}

	/**
	 * fournit le prix hors-taxe total de la commande
	 * 
	 * @return le prix hors-taxe total de la commande
	 */
	public float totalHT() {
		float total = 0;
		for (Reference ref : this.lesArticles.keySet()) {
			total = total + this.lesArticles.get(ref) * this.catalogue.getPrixHT(ref);
		}
		return total;
	}

	/**
	 * La commande est exp�di�e au client. Son statut passe � "exp�di�e",
	 * 
	 * on ne peut ensuite plus modifier les articles et quantit�s command�s.
	 */
	public void expedie() {
		this.statut = StatutCommande.expediee;
	}

	/**
	 * la commande a �t� livr�e au client . Son statut passe � "livr�e}". on ne
	 * peut plus modifier les articles et quantit�s command�s.
	 */
	public void livree() {
		this.statut = StatutCommande.livree;
	}

	/**
	 * affiche la commande : le client, puis les articles � raison d'un article
	 * et sa quantit� command�e par ligne. En fin de commande le prix total
	 * hors-taxe est affich�, ainsi que le statut de la commande.
	 */
	public void affiche() {
		System.out.println("Client : " + this.numClient);
		for (Reference ref : this.lesArticles.keySet()) {
			System.out.println("article : " + this.catalogue.getArticle(ref) + " -> quantit� : " + this.lesArticles.get(ref));
		}
		System.out.println(this.totalHT());
	}

}
