/*
 * Created on 13 janv. 2006
 *
 */
package examen.sujet;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class Mois {

   // d�fini un type �num�r�

}
