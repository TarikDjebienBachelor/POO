/*
 * Created on 13 janv. 2006
 *
 */
package examen.sujet;

/**
 * @author <a href="mailto:routier@lifl.fr">routier </a>
 * 
 * TODO
 */
public class Date implements Comparable {

   private int jour;
   private Mois mois;
   private int annee;

   /**
    *  
    */
   public Date() {
      super();
      // TODO Auto-generated constructor stub
   }

   /*
    * (non-Javadoc)
    * 
    * @see java.lang.Comparable#compareTo(java.lang.Object)
    */
   public int compareTo(Object arg0) {
      return 0;
   }

   public String toString() {
      return "";
   }

   public boolean equals(Object o) {
      return true;
   }

   /**
    * @return Returns the annee.
    */
   public int getAnnee() {
      return annee;
   }

   /**
    * @return Returns the jour.
    */
   public int getJour() {
      return jour;
   }

   /**
    * @return Returns the mois.
    */
   public Mois getMois() {
      return mois;
   }
   
   /**
    * @param d la date de comparaison
    * @return nombre de jours entre this et d, positif si this est post�rieure � d
    */
   public int differenceEnJours(Date d) { return 0; }
   
   public static Date aujourdhui() {
      return new Date();
   }
}
