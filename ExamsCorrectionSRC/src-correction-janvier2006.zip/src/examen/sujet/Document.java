package examen.sujet;
import examen.reponse.Auteur;
   public interface Document {
      /** @return l'auteur de ce document  */
      public Auteur getAuteur();

      /** @return le titre de ce document */
      public String getTitre();

      /** @return une cha�ne de caract�res repr�sentant ce document */
      public String toString();

      /** @param l'objet � tester
        * @return true si le param�tre est un document identique � this */
      public boolean equals(Object o);

      /** indique si le document est emprunt� ou non 
       * @return true ssi le document est emprunt� 
       */
      public boolean estEmprunte();
      /** permet de marquer comme emprunt� ou non un document
       * @param b true si le document est emprunt�, false si il est disponible
       */
      public boolean setEmprunte(boolean b);

}
