/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import examen.sujet.Document;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class AuteurVivantSelectionneur implements Selectionneur {

   private int annee;
   public AuteurVivantSelectionneur(int annee) {
      this.annee = annee;
   }	

   public boolean estSatisfaitPar(Document d) {
      boolean estNe = d.getAuteur().getNaissance().getAnnee() <= annee;
      if (d.getAuteur().getDeces() == null) {
         return estNe;
      } else {
         return estNe && d.getAuteur().getDeces().getAnnee() > annee;
         	
      }      
   }

}
