/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import examen.sujet.Document;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class MotDansTitreSelectionneur implements Selectionneur {

   private String mot;
   
   public MotDansTitreSelectionneur(String mot) {
      this.mot = mot;
   }	

   public boolean estSatisfaitPar(Document d) {
      String titre = d.getTitre();
      return titre.indexOf(mot) != -1;
   }

}
