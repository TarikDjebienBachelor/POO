/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import java.util.*;
import examen.sujet.*;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class Mediatheque {

   private static int DELAI_RETARD = 15;

   private BaseDocuments bdDoc;
   private Map lesEmprunteurs;
   public Mediatheque(BaseDocuments bdDoc) {
      this.bdDoc = bdDoc;
      this.lesEmprunteurs = new HashMap();
   }
   /** ajoute un nouveau client qui sera identifi� par le code barre 
    * donn�
    */
   public void ajouteClient(CodeBarre cb, Emprunteur truc) {
      this.lesEmprunteurs.put(cb,truc);	
   }
   /** le client identifi� par le code barre emprunte le document d
    * si c'est possible (document libre et pas d'autre document emprunt�)
    * sinon une exception est lev�e.
    */
   public void emprunteDoc(CodeBarre cb, Document d) throws Exception {
      Emprunteur emprunteur = (Emprunteur) this.lesEmprunteurs.get(cb);
      if (d.estEmprunte()) {
         throw new Exception("document deja emprunte");
      } else {
         emprunteur.emprunte(d); // peut lancer une Exception si deja un document emprunte
         this.bdDoc.emprunte(d);
      }
   }
   /** le client identifi� par cb rend son document, il ne se passe rien
    * si il n'en avait emprunt� aucun */
   public void rendDoc(CodeBarre cb) {
      Emprunteur emprunteur = (Emprunteur) this.lesEmprunteurs.get(cb);
      Document doc = emprunteur.getDocument();
      if ( doc != null) {
         this.bdDoc.rend(doc);
         emprunteur.rendDocument();
      } 
   }
   /** retourne un it�rateur sur les clients qui sont en retard pour
    * rendre leur document au jour d'aujourd'hui*/
   public Iterator enRetard() {
      List retardataires = new ArrayList();
      Iterator it_emprunteurs = this.lesEmprunteurs.values().iterator();
      while (it_emprunteurs.hasNext()) {
         Emprunteur emprunteur = (Emprunteur) it_emprunteurs.next();
         examen.sujet.Date d = emprunteur.getDateEmprunt();
         if ( d!=null // il y a un document emprunte
               && d.differenceEnJours(examen.sujet.Date.aujourdhui()) > DELAI_RETARD) {
            retardataires.add(emprunteur);
         }
      }
      
      return retardataires.iterator();
   } 
}
