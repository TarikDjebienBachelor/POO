/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import java.util.*;

import examen.sujet.Document;

/**
 * @author <a href="mailto:routier@lifl.fr">routier </a>
 * 
 * TODO
 */
public class BaseDocuments {

   private List lesDocuments;

   /**
    *  
    */
   public BaseDocuments() {
      this.lesDocuments = new ArrayList();
   }

   /**
    * ajoute un document dans la base de documents
    * 
    * @param d
    *           le document � ajouter
    */
   public void ajouter(Document d) {
      this.lesDocuments.add(d);
   }

   /**
    * supprime un document de la base de documents (si il est plusieurs fois
    * pr�sents, une seule des occurrences est supprime�e). Il importe peu que le
    * document soit emprunt� ou non ,au moment de sa suppression.
    * 
    * @param d
    *           le document � supprimer
    * @return le document supprim�, null si il n'existe pas
    */
   public Document supprimer(Document d) {
      boolean b = this.lesDocuments.remove(d);
      if (b) {
         return d;
      } else {
         return null;
      }
   }

   /**
    * affiche tous les documents de la mediath�que (pour impression du catalogue
    * par exemple)
    */

   public void afficher() {
      Iterator it = this.lesDocuments.iterator();
      while (it.hasNext()) {
         System.out.println(it.next());
      }
   }

   /**
    * indique si le document donn� est disponible (non emprunt�)
    * 
    * @param d
    *           le document concerne
    * @return true si le document donn� est disponible (non emprunt�)
    * @exception NoSuchElementException
    *               si le document n'existe pas dans la mediath�que
    */
   public boolean estDisponible(Document d) throws NoSuchElementException {
      if (this.lesDocuments.contains(d)) {
         Document leBon = (Document) this.lesDocuments.get(this.lesDocuments.indexOf(d));
         return leBon.estEmprunte();
      } else {
         throw new NoSuchElementException(d + " n'existe pas");
      }
   }

   /**
    * permet d'emprunter un document
    * 
    * @param d
    *           le document concerne
    * @exception NoSuchElementException
    *               si le document n'existe pas dans la mediath�que
    */
   public void emprunte(Document d) throws NoSuchElementException {
      if (this.lesDocuments.contains(d)) {
         Document leBon = (Document) this.lesDocuments.get(this.lesDocuments.indexOf(d));
         leBon.setEmprunte(true);
      } else {
         throw new NoSuchElementException(d + " n'existe pas");
      }
   }

   /**
    * permet de rendre un document
    * 
    * @param d
    *           le document concerne
    */
   public void rend(Document d) {
      Document leBon = (Document) this.lesDocuments.get(this.lesDocuments.indexOf(d));
      leBon.setEmprunte(false);
   }

   
   
   
   // 3.1
   
   	public Iterator selectionne(Selectionneur s) {
   	   List l = new ArrayList();
   	   Iterator it = this.lesDocuments.iterator();
   	   Document doc;
   	   while (it.hasNext()) {
   	      doc = (Document) it.next();
   	      if (s.estSatisfaitPar(doc)) {
   	         l.add(doc);
   	      }
   	   }
   	   return l.iterator();
   	}
   
}
