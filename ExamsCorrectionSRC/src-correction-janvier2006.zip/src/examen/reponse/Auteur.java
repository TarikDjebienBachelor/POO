/*
 * Created on 13 janv. 2006
 *
 */
package examen.reponse;

import examen.sujet.Date;

/**
 * @author <a href="mailto:routier@lifl.fr">routier </a>
 * 
 * TODO
 */
public class Auteur {

   private Date naissance;
   private Date deces;
   private String name;

   /**
    *  
    */
   public Auteur(String name, Date naissance) {
      this(name, naissance, null);
   }

   public Auteur(String name, Date naissance, Date deces) {
      this.name = name;
      this.deces = deces;
      this.naissance = naissance;
   }

   	public boolean equals(Object o) {
   	   try {
   	      Auteur lAutre = (Auteur) o;
   	      boolean resultat = this.name.equals(lAutre.name) && this.naissance.equals(lAutre.naissance);
   	      if (this.deces == null) {
   	         return resultat && lAutre.deces == null;
   	      } else {
   	         return resultat && this.deces.equals(lAutre.deces);
   	      }
   	   } catch (ClassCastException e) {
   	      return false;
   	   }
   	}
   
   /**
    * @return Returns the deces.
    */
   public Date getDeces() {
      return deces;
   }

   /**
    * @return Returns the naissance.
    */
   public Date getNaissance() {
      return naissance;
   }

   /**
    * @return Returns the name.
    */
   public String getName() {
      return name;
   }
}
