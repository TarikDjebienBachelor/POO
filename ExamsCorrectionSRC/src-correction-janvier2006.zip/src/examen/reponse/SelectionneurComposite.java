/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import java.util.*;

import examen.sujet.Document;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class SelectionneurComposite implements Selectionneur {

   private List lesSelectionneurs;
   
   
   public SelectionneurComposite() {
      this.lesSelectionneurs = new ArrayList();
   }

   public boolean estSatisfaitPar(Document d) {
      boolean result = true;
      Iterator it = this.lesSelectionneurs.iterator();
      while (result && it.hasNext()) {
         result = ((Selectionneur) it.next()).estSatisfaitPar(d); 
      }
      return result;
   }


   public void add(Selectionneur s) {
      this.lesSelectionneurs.add(s);
   }
}
