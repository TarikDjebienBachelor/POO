/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import examen.sujet.*;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class Emprunteur {

   private Document document;
   private Date dateEmprunt;
   private String nom;
   
   public Emprunteur(String nom) {
      this.nom = nom;
   }
   
   public void rendDocument() {}
   
   public void emprunte(Document d) throws Exception {}
   
 

   /**
    * @return Returns the dateEmprunt.
    */
   public Date getDateEmprunt() {
      return dateEmprunt;
   }
   /**
    * @return Returns the document.
    */
   public Document getDocument() {
      return document;
   }
   /**
    * @return Returns the nom.
    */
   public String getNom() {
      return nom;
   }
}
