/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import examen.sujet.Document;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public interface Selectionneur {
   public boolean estSatisfaitPar(Document d);

 
}
