/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class CodeBarre {

  private String codeBarre;

   public CodeBarre(String code) {
      this.codeBarre = code;
   }
  	
   public int hashCode() { 
      	return this.codeBarre.hashCode();   
   }
   public boolean equals(Object o) {
      try {
      CodeBarre lAutre = (CodeBarre) o;
      return this.codeBarre.equals(lAutre.codeBarre);
      }
      catch(ClassCastException e) {
         return false;
      }
   }

}
