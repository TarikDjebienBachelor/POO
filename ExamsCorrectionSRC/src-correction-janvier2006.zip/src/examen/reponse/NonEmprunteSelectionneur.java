/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import examen.sujet.Document;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class NonEmprunteSelectionneur implements Selectionneur {

 

   /* (non-Javadoc)
    * @see examen.reponse.Selectionneur#estSatisfaitPar(examen.sujet.Document)
    */
   public boolean estSatisfaitPar(Document d) {
      return ! d.estEmprunte();
   }

}
