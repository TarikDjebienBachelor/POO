/*
 * Created on 3 f�vr. 2006
 *
 */
package examen.reponse;

import java.util.Iterator;

/**
 * @author <a href="mailto:routier@lifl.fr">routier</a>
 *
 * TODO
 */
public class QuestionTroisSix {

   public static void main(String[] args) {
      BaseDocuments bdDoc = new BaseDocuments();
      Selectionneur s1 = new MotDansTitreSelectionneur("Anneaux");
      Selectionneur s2 = new AuteurVivantSelectionneur(1832);
      SelectionneurComposite s3 = new SelectionneurComposite();
      s3.add(s1);
      s3.add(s2);
      
      Iterator it1 = bdDoc.selectionne(s1);
      Iterator it2 = bdDoc.selectionne(s2);
      Iterator it3 = bdDoc.selectionne(s3);
   }
   
}
