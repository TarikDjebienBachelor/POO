package scrutin;

public class VoteNonClosException extends Exception {

}
