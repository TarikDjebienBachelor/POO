package scrutin;

public class VoteClosException extends Exception {

}
