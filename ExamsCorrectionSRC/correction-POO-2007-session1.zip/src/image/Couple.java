package image;

import java.awt.Color;

public class Couple {
	private int nombre;
	private Color color;
	
	public Couple(int n, Color c){
		this.nombre = n;
		this.color = c;
	}

	public Color getColor() {
		return color;
	}

	public int getNombre() {
		return nombre;
	}
	
	public String toString() {
		return "("+this.nombre+","+this.color+")";
	}
}
