/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.sujet;

import janvier2005.solution.ListeCoureurs;

import java.util.Map;

/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 *
 * TODO
 */
public class Etape {

    public void disputer(ListeCoureurs lc) {
    }

    public Map resultats()  throws EtapeNonCourueException {
	return null;
    }
    
    public ListeCoureurs abandons() throws EtapeNonCourueException {
        return null;
    }
}
