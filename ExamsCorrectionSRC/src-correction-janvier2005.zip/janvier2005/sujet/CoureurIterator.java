/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.sujet;
import janvier2005.solution.Coureur;
import java.util.Iterator;
/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 *
 * TODO
 */
public class CoureurIterator {
    private Iterator iterator;
    /** @param un it�rateur sur un objet de type List que l'on supposera
     * ne contenanir que des objets Coureur
     */
    public CoureurIterator(Iterator iterator) {
        this.iterator = iterator;
    }
    public boolean hasNext() {
        return this.iterator.hasNext();
    }
    public Coureur next() {
        return (Coureur) this.iterator.next();
    }                                                           
}
