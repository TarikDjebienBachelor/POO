/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.sujet;
import janvier2005.solution.Temps;

/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 *
 * TODO
 */
public class Resultat {
    private Temps temps;
    private int pointsVert;
    private int pointsMontagne;

    public Resultat(Temps temps, int pointsVert, int pointsMontagne) {
        this.temps = temps;
        this.pointsVert = pointsVert;
        this.pointsMontagne = pointsMontagne;
    }


    
    /**
     * @return Returns the pointsMontagne.
     */
    public int getPointsMontagne() {
        return this.pointsMontagne;
    }
    /**
     * @return Returns the pointsVerts.
     */
    public int getPointsVert() {
        return this.pointsVert;
    }
    /**
     * @return Returns the tps.
     */
    public Temps getTemps() {
        return this.temps;
    }
    
    public void add(Resultat r) {
        this.temps.add(r.temps);
        this.pointsVert = this.pointsVert+ r.pointsVert;
        this.pointsMontagne = this.pointsMontagne + r.pointsMontagne;
    }
}
