/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.sujet;

/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 *
 * TODO
 */
public class EtapeNonCourueException extends Exception {

}
