/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.solution;

import janvier2005.sujet.CoureurIterator;

import java.util.*;

/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 *
 * TODO
 */
public class ListeCoureurs {

    private List l;
    
    public ListeCoureurs() {
        this.l = new ArrayList();
    }
    
    public void add(Coureur c) {
        this.l.add(c);
    }
    
    public CoureurIterator iterator() {
        return new CoureurIterator(this.l.iterator());
    }
    
    public int size() {
        return this.l.size();
    } 
    
    public boolean remove(Coureur c) {
        return  this.l.remove(c);
    }
    // question 6

    public ListeCoureurs tri(Comparator c) {
        Collections.sort(this.l,c);
        return this; // en admettant que ce ne soit pas g�nant de changer l'ordre des coureurs, le sujet ne dit rien contre
    }

}
