/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.solution;

import janvier2005.sujet.*;

import java.util.*;

/**
 * @author <a href="ailto:routier@lifl.fr"routier </a>
 * 
 * TODO
 */
public class TourDeFrance {

    private static int AGE_JEUNE = 25;

    private List lesEtapes;
    private Map lesCoureurs;
    private ListeCoureurs lesAbandons;

    public TourDeFrance(List lesEtapes, ListeCoureurs coureurs) {
        this.lesEtapes = lesEtapes;
        this.lesCoureurs = new HashMap();
        for (CoureurIterator it = coureurs.iterator(); it.hasNext();) {
            this.lesCoureurs.put(it.next(), new Resultat(new Temps(),0 , 0));
        }
        this.lesAbandons = new ListeCoureurs();
    }

    private void disputeEtape(Etape etape) {
        ListeCoureurs participants = this.getListeDesCoureurs();
        etape.disputer(participants);
        try {
            Map resultats = etape.resultats();

            for (Iterator it = this.lesCoureurs.keySet().iterator(); it.hasNext();) {
                Coureur c = (Coureur) it.next();
                Resultat resEtape = (Resultat) resultats.get(c);
                Resultat resActuel = (Resultat) lesCoureurs.get(c);
                resActuel.add(resEtape);
                this.lesCoureurs.put(c, resActuel);
            }

            for (CoureurIterator it = etape.abandons().iterator(); it.hasNext();) {
                Coureur c = (Coureur) it.next();
                this.lesAbandons.add(c);
                this.lesCoureurs.remove(c);
            }
        } catch (EtapeNonCourueException e1) {
            e1.printStackTrace(); // ne peut pas se produire
        }
    }

    public void disputeCourse() {
        for (Iterator it = lesEtapes.iterator(); it.hasNext();) {
            this.disputeEtape((Etape) it.next());
        }
    }

    public ListeCoureurs abandons() {
        return this.lesAbandons;
    }

    private ListeCoureurs getListeDesCoureurs() {
        ListeCoureurs participants = new ListeCoureurs();
        for (Iterator it = this.lesCoureurs.keySet().iterator(); it.hasNext();) {
            participants.add((Coureur) it.next());
        }
        return participants;
    }

    private Coureur meilleurDansListe(ListeCoureurs participants, Comparator c) {
        participants.tri(new ComparateurTemps(this.lesCoureurs));
        return participants.iterator().next();
        // ou si on veut g�rer le cas de la liste vide :
//        Iterator it = participants.iterator();
//        if (it.hasNext()) {
//            return (Coureur) it.next();
//        } else {
//            return null;
//        }
    }

    public Coureur maillotJaune() {
        return this.meilleurDansListe(this.getListeDesCoureurs(), new ComparateurTemps(this.lesCoureurs));
    }

    public Coureur meilleurJeune() throws NoSuchElementException {
        ListeCoureurs participants = this.getListeDesCoureurs();
        ListeCoureurs jeunes = new ListeCoureurs();
        for (CoureurIterator it = participants.iterator(); it.hasNext();) {
            Coureur coureur = it.next();
            if (coureur.getAge() <= AGE_JEUNE) {
                jeunes.add(coureur);
            }
        }
        if (jeunes.size() == 0) {
            throw new NoSuchElementException("pas de jeune en course");
        }
        return this.meilleurDansListe(jeunes, new ComparateurTemps(this.lesCoureurs));
    }

    public Coureur maillotVert() {
        return this.meilleurDansListe(this.getListeDesCoureurs(), new ComparateurVert(this.lesCoureurs));
    }

    public Coureur maillotMontagne() {
        return this.meilleurDansListe(this.getListeDesCoureurs(), new ComparateurMontagne(this.lesCoureurs));
    }

}

