/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.solution;

/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 *
 * TODO
 */
public class Coureur {

    // �ventuellement mettre les attributs en "final" puisqu'on ne veut pas les modifier
    private String nom;
    private String prenom;
    private String licence;
    private int age;

    public Coureur(String nom, String prenom, String licence, int age) {
        this.nom = nom;
        this.prenom = prenom;
        this.licence = licence;
        this.age = age;
    }

    /**
     * @return Returns the age.
     */
    public int getAge() {
        return age;
    }

    /**
     * @return Returns the licence.
     */
    public String getLicence() {
        return licence;
    }

    /**
     * @return Returns the nom.
     */
    public String getNom() {
        return nom;
    }

    /**
     * @return Returns the prenom.
     */
    public String getPrenom() {
        return prenom;
    }

    
    
    // reponse question Q 4
    public int hashCode() {
        return this.licence.hashCode();
    }
    public boolean equals(Object o) {
        Coureur lAutre = (Coureur) o;
        return this.licence.equals(lAutre.licence); // devrait �tre suffisant d'apr�s le sujet
        // return this.nom.equals(lAutre.nom) && this.prenom.equals(lAutre.prenom) && this.licence.equals(lAutre.licence) && this.age == lAutre.age;
    }
}


