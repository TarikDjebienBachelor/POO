/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.solution;

import janvier2005.sujet.Resultat;
import java.util.Comparator;
import java.util.Map;

/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 *
 * TODO
 */
public class ComparateurVert implements Comparator {


    private Map lesCoureurs;

    public ComparateurVert(Map lesCoureurs) {
        this.lesCoureurs = lesCoureurs;
    }
    
    /** (non-Javadoc)
     * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
     */
    public int compare(Object o1, Object o2) {
        Resultat r1 = (Resultat) this.lesCoureurs.get(o1);
        Resultat r2 = (Resultat) this.lesCoureurs.get(o2);
                
        return r1.getPointsVert() - r2.getPointsVert();
    }
}
