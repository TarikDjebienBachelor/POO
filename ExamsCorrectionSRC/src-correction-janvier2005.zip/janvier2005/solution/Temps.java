/*
 * Created on 5 d�c. 2004
 *
 */
package janvier2005.solution;

/**
 * @author <a href="ailto:routier@lifl.fr"routier</a>
 *
 * TODO
 */
public class Temps implements Comparable {

    private int h;
    private int mn;
    private int s;
    
    public Temps() {
        this(0,0,0);
    }
    
    public Temps(int h, int mn, int s) {
        // ou creer une methode private normalise qui g�re les %60 et sert aussi dans add()	
        this.s =  s % 60;
        mn = mn + s/60;
        this.mn = mn % 60;
        this.h = h + mn/60;
    }
    
    
    /**
     * @return Returns the h.
     */
    public int getH() {
        return this.h;
    }
    /**
     * @return Returns the mn.
     */
    public int getMn() {
        return this.mn;
    }
    /**
     * @return Returns the s.
     */
    public int getS() {
        return this.s;
    }
    
    /**
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object o) {
        Temps lAutre = (Temps) o;
        return (this.h*60+this.mn)*60+this.s - (lAutre.h*60+lAutre.mn)*60+lAutre.s; 
    }

    public void add(Temps t) {
        int sec = this.s + t.s;
        this.s = sec % 60;
        int min = this.mn + t.mn + sec /60;
        this.mn = min % 60;
        this.h = this.h + t.h + min / 60;	
    }
}
