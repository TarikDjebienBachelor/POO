
public class GameOfLife {
    
    private Environment environment; // l'environnement torique
    private GridDisplayer displayer; // pour l'affichage 
    
    public GameOfLife (int width, int height) {
	environment = new Environment(width, height);
       }
    
    /** initialise l'environnement avec des cellules dont
     *  l'�tat initial est tir� al�atoirement 
     */
    public void randomInit() {
	//... 
    }
    
    /** fixe le "gridDisplayer"
     */
       public void setGridDisplayer(GridDisplayer displayer) {
	   //...
       }
    /** execute le jeu de la vie pendant textit{nbSteps} cycles
     * et affiche l'environnement apr�s chaque cycle
     */
    public void execute(int nbSteps) {
	//...
    }
    
    /** execute un seul cycle du jeu de la vie. textbf{Toutes} les
     * cellules �voluent textbf{simultan�ment}.
     */
    private void executeOneCycle() {
        //...
    }
}// GameOfLife
