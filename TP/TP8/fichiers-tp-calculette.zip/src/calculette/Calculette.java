package calculette ;
/** D�finit la notion g�n�rale de calculette */
public interface Calculette {
    /** Retourne la valeur courant de la calculette 
      * C'est cette valeur qui est affich�e � l'�cran de a calculatrice.
      * @return la valeur courante de la calculette 
    */
    public int getValeurCourante () ;
    /** Appui sur une touche de chiffre 
      * @param c la valeur enti�re correspondant au chiffre 
    */
    public void enfoncerChiffre (int c) ;
    /** Appui sur la touche + */ 
    public void enfoncerPlus () ;
    /** Appui sur la touche - */ 
    public void enfoncerMoins () ;
    /** Appui sur la touche / */ 
    public void enfoncerDiv () ;
    /** Appui sur la touche * */ 
    public void enfoncerMult () ;
    /** Appui sur la touche = */ 
    public void enfoncerEgal () ;
    /** Appui sur la touche Del */ 
    public void enfoncerDel () ;
    /** Appui sur la touche CC */ 
    public void enfoncerRaz () ;
}
