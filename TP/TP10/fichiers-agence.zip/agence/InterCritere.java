package agence;
import java.util.*;

public class InterCritere implements Critere {
    
    private List<Critere> lesCriteres;

    public InterCritere() {
	// a completer
    }

    public void addCritere(Critere c) {
	// a completer
    }

    public boolean estSatisfaitPar(Voiture v) {
	// a modifier
	return false;
    }
}
