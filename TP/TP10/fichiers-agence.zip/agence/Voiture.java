package agence;
public class Voiture {
    private String marque;
    private String modele;
    private int annee;
    private int prix;
    public Voiture(String marque, String modele, int annee, int
		   prix) {
	this.marque = marque;
	this.modele = modele;
	this.annee = annee;
	this.prix = prix;
    }
    public String getMarque() {
	return this.marque;
    }
    public String getModele() {
	return this.modele;
    }
    public int getAnnee() {
	return this.annee;
    }
    public int getPrix() {
	return this.prix;
    }
    public boolean equals(Object o) {
	if (o instanceof Voiture) {
	    Voiture lAutre = ((Voiture) o);
	    return this.marque.equals(lAutre.marque)
		&& this.modele.equals(lAutre.modele)
		&& this.annee == lAutre.annee 
		&& this.prix == lAutre.prix;
	}
	else {
	    return false;
	}
    }
    public String toString() {
	return this.annee + " " + this.marque + " " + this.prix;
    }
}
