package agence;

public class AgenceTD {
    private Voiture[] voitures;

    public AgenceTD() { 
	//...
    }

    public void afficheSelection(Critere c) {
	for(int i= 0; i < voitures.length; i++) {
	    if (c.estSatisfaitPar(voitures[i])) {
		System.out.println(voitures[i]);
	    }
	}
    }

}
