package agence;
public class InterCritereTD implements Critere {
    private Critere critere1;
    private Critere critere2;
    public InterCritereTD(Critere critere1, Critere critere2) {
	this.critere1 = critere1;
	this.critere2 = critere2;
    }
    public boolean estSatisfaitPar(Voiture v) {
	return this.critere1.estSatisfaitPar(v) 
	    && this.critere2.estSatisfaitPar(v);
    }
}
