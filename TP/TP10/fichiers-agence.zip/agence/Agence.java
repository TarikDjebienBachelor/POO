package agence;

import java.util.*;

public class Agence {
    private List<Voiture> voitures;

    // associe les clients (String) et les voitures lou�es
    // (une seule location possible par client)
    private Map<String,Voiture> lesLocations;

    public Agence() {
	// a completer
    }

    public Iterator<Voiture> selectionne(Critere c) {	
	// a modifier
	return null;
    }    

    public void afficheSelection(Critere c) {
	// a completer
    }

    public void loueVoiture(String client, Voiture v) 
	throws java.util.MissingResourceException {
	// a completer
    }
    
    public boolean estLoueur(String client){
	// a modifier
	return false;
    }
    
    public boolean estLoue(Voiture v){
	// a modifier
	return false;
    }
    
    public void rendVoiture(String client){
	// a completer
    }
    
    public Collection<Voiture> lesVoituresLouees(){
	// a modifier
	return null;
    }

}
