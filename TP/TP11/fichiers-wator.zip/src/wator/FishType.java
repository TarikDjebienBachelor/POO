
/**
 * FishType.java
 *
 *
 * Created: Fri Nov 02 15:42:00 2001
 *
 * @author <a href="mailto:routier@lifl.fr">Jean-Christophe Routier</a>
 * @version
 */
package wator;

public class FishType {
    private String name;

    private FishType (String name){
	this.name = name;
    }
    public static final FishType TUNA = new FishType("Tuna");
    public static final FishType SHARK = new FishType("Shark");

    public String toString() {
	return this.name;
    }
}// FishType
