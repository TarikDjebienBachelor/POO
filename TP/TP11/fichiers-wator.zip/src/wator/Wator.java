
/**
 * Wator.java
 *
 *
 * Created: Fri Nov 02 15:41:03 2001
 *
 * @author <a href="mailto: "Jean-Christophe Routier</a>
 * @version
 */
package wator;
import grid.*;

public class Wator {

    // A COMPLETER

}// Wator
