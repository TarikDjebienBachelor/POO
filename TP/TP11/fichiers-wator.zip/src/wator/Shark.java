/**
 * Shark.java
 *
 *
 * Created: Fri Nov 02 15:37:43 2001
 *
 * @author <a href="mailto: "Jean-Christophe Routier</a>
 * @version
 */
package wator;
import grid.*;

public class Shark implements Fish {
    private static final FishType TYPE = FishType.SHARK;
    private static final char SHARK_CHAR = 'S';

    // A COMPLETER !!!

    /** returns a char that represents the fish
     * @return the char
     */
    public char getDescriptionChar() {
	return SHARK_CHAR;
    }
    
}// Shark
