
/**
 * Environment.java
 *
 *
 * Created: Fri Nov 02 15:38:40 2001
 *
 * @author <a href="mailto:routier@lifl.fr">Jean-Christophe Routier</a>
 * @version
 */
package wator;
import grid.*;

public class Environment implements Grid {
    
    private GridDisplayer gridDisplayer;
    private Fish[][] fishes;

    // A COMPLETER !!!

    /** sets the grid displayer 
     * @param displayer the grid displayer
     */
    public void setGridDisplayer(GridDisplayer displayer) {
	gridDisplayer = displayer;
    }


    /** displays the environment using a GridDisplayer
     * @param msg the msg given to the displayer
     */
    public void display(String msg) {
	gridDisplayer.display(this, msg);
    }

    /** fish at position (i,j) acts
     * @param i 
     * @param j
     */
    public void actAt(int i, int j) {
	Fish fish = fishes[i][j];
	if (fish != null) {
	    Position current = fish.getPosition();
	    Position aim = current.randomNeighbour(width, height);
	    if (fish.canMove(fishes[aim.getX()][aim.getY()])) {		
		fish.setPosition(aim);
		fishes[aim.getX()][aim.getY()] = fish;
		fishes[i][j] = fish.giveBirth(current);
	    }
	    if (fish.isDead()) {
		fishes[fish.getPosition().getX()][fish.getPosition().getY()] = null;
	    }
	} // else nothing happens
    }


    /** returns the char to be displaid in the box at position<em>p</em>
     * @param p the position
     * @return the char to be displaid
     */
    public char getCharAtPosition(Position p) {
	Fish f = fishes[p.getX()][p.getY()];
	if (f != null) {
	    return fishes[p.getX()][p.getY()].getDescriptionChar();
	}
	else {
	    return ' ';
	}
    }

 
}// Environment
