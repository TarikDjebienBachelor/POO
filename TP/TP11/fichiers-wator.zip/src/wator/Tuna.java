
/**
 * Tuna.java
 *
 *
 * Created: Fri Nov 02 15:37:02 2001
 *
 * @author <a href="mailto:routier@lifl.fr">Jean-Christophe Routier</a>
 * @version
 */
package wator;
import grid.*;

public class Tuna implements Fish {
    
    private static final FishType TYPE = FishType.TUNA;
    private static final char TUNA_CHAR = 'T';

    // A COMPLETER !!!

    /** returns a char that represents the fish
     * @return the char
     */
    public char getDescriptionChar() {
	return TUNA_CHAR;
    }


}// Tuna
