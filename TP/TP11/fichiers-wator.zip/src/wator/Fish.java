
/**
 * Fish.java
 *
 *
 * Created: Fri Nov 02 15:36:12 2001
 *
 * @author <a href="mailto:routier@lifl.fr">Jean-Christophe Routier</a>
 * @version
 */
package wator;
import grid.*;

public interface Fish {

    /** tells if the fish can move to the position occupied by the fish <em>f</em>
     * @param f the fish that stays at aimed position
     * @return <em>true</em> if move is possible
     */  
    public boolean canMove(Fish f);
    /** returns the current position of the fish
     * @return the current position of the fish
     */
    public Position getPosition();
    /** sets the  position of the fish
     * @param the position of the fish
     */
    public void setPosition(Position p);
    /** returns the type of the fish
     * @return  the type of the fish
     */
    public FishType getFishType();
    /** returns the duration of the period of gestation
     * @return  the duration of the period of gestation
     */
    public int getGestationPeriod();
    /** sets the duration of the period of gestation
     * @param period the period of gestation
     */
    public void setGestationPeriod(int period);
    /** returns if gestation period is over, the new borned fish, this one borns at the position that has just been left
     * @param lastPosition the position 
     *  @return the new borned fish (null if none)
     */
    public Fish giveBirth(Position lastPosition);
    /** returns <em>true</em> iff the fish is dying
     * @return  <em>true</em> iff the fish is dying
     */
    public boolean isDead();
    /** returns a char that represents the fish
     * @return the char
     */
    public char getDescriptionChar();
    /** returns a color used to display the fish
     * @return the color
     */
    public java.awt.Color getColor();
    
}// Fish
