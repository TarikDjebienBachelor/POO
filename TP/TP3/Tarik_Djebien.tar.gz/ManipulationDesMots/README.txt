README : 

// Auteur : Djebien Tarik
// Date   : Fevrier 2010
// Objet  : POO - Manipulation sur des Mots

Ci-Joint le TP numero 3

Arborescence de l'archive Tarik_Djebien.tar.gz :
    |
    |_____README.txt
    |
    |_____manifest-ex
    |
    |_____classes/ Mot.class Test.class
    |                     
    |_____docs/ La JavaDoc: index.html Mot.html etc...
    |                     
    |_____src/ Mot.java Test.java

Note :

Pour le jar executable, je n'ai pas reussi je pense que mon erreur est située sur l'absence de Paquetages ? 
Merci pour vos remarques.

Pour les commentaires :

tarik.djebien@etudiant.univ-lille1.fr

Cordialement.
