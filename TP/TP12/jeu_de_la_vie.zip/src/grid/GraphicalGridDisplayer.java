
/**
 * GraphicalGridDisplayer.java
 *
 *
 * Created: Mon Nov 05 09:29:47 2001
 *
 * @author <a href="mailto:routier@lifl.fr">Jean-Christophe Routier</a>
 * @version
 */
package grid;

import javax.swing.*;
import java.awt.*;

/** display a grid in a JFrame
 */
public class GraphicalGridDisplayer extends JFrame implements GridDisplayer{
    
    public static int SQUARE_SIZE = 10;
    public static int SQUARE_SIZE_INT = SQUARE_SIZE;

    private java.awt.Color[][] oldGrid;
    private Insets insets;
    
    public GraphicalGridDisplayer(int width, int height) {
	addWindowListener(new MyWindowAdapter());
	oldGrid = new java.awt.Color[width][height];
	for(int i=0;i<oldGrid.length;i++) {
	    for(int j=0;j<oldGrid[0].length;j++) {
		this.oldGrid[i][j] = Color.WHITE;
	    }}
	this.setVisible(true);
	this.insets = this.getInsets();
	setSize(width*SQUARE_SIZE+(this.insets.left+this.insets.right), height*SQUARE_SIZE+(this.insets.top+this.insets.bottom));
    }
    

    /** paint the grid's frame, a pause of 50ms is done once paint is achieved
     */
    public void paint(Graphics g) {
	Graphics2D myGraphics = (Graphics2D) g;

	for(int i=0;i<oldGrid.length;i++) {
	    for(int j=0;j<oldGrid[0].length;j++) {
		    myGraphics.setColor(oldGrid[i][j]);
		    myGraphics.fillRect(i*SQUARE_SIZE+this.insets.left,j*SQUARE_SIZE+this.insets.top,SQUARE_SIZE_INT,SQUARE_SIZE_INT);
	    }
	}

	try {

	    synchronized(this) {
		Thread.sleep(50);
		this.notifyAll();
	    }
	} catch(Exception e) {}
    }


    /** displays the grid, 
     * @param grid the grid to be displaid
     * @param msg a msg : displaid in the title bar of the frame
     */
    public void display(Grid toBeRepaint, String msg) {
	setTitle(msg);

	int w = toBeRepaint.getWidth();
	int h = toBeRepaint.getHeight();
	
	for (int i=0; i<w; i++) {
	    for (int j=0; j<h;j++) {
		java.awt.Color newColor = toBeRepaint.getColorAtPosition(new Position(i, j));
		
		if(!newColor.equals(oldGrid[i][j])) {
		    oldGrid[i][j] = newColor;
		}
	    }
	}

	try {
	    synchronized(this) {
		repaint(1);
		this.wait();
	    }

	} catch(Exception e) {}
    }

    class MyWindowAdapter extends java.awt.event.WindowAdapter {
	public void windowClosing(java.awt.event.WindowEvent e) {
	    System.exit(0);
	}
    }

}// GraphicalGridDisplayer
