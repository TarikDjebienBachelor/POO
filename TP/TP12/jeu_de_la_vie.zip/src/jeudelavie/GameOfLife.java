package jeudelavie;
import grid.*;
import java.io.*;
import java.util.*;

public class GameOfLife {
    
    private Environment environment; // l'environnement torique
    private GridDisplayer displayer; // pour l'affichage 
    
    public GameOfLife (int width, int height) {
    	environment = new Environment(width, height);
    }
    
    /** initialise l'environnement avec des cellules dont
     *  l'etat initial est tire aleatoirement 
     * @param pourcentActive pourcentage de cellules actives initialement
     */
    public void randomInit(int pourcentActive) {
	// A COMPLETER
    }

    public int getWidth() {
	return this.environment.getWidth();
    }


    public int getHeight() {
	return this.environment.getHeight();
    }
 
    /** initialise l'environnement � partir des informations 
     * lues dans un ficheir "texte"
     * @param fileName le nom du fichier
     */
    public void initFile(String fileName) {
	// A COMPLETER
    }
    
    
    /** fixe le "gridDisplayer"
    * @param displayer Objet symbolisant l'affichage (mode texte ou graphique)
    */
    public void setGridDisplayer(GridDisplayer displayer) {
	this.displayer=displayer;
    }
    
       
    /** execute le jeu de la vie pendant <i>nbSteps</i> cycles
     * et affiche l'environnement apr�s chaque cycle
     */
    public void execute(int nbSteps) {
	// A COMPLETER
    }
    
	
    
    /** execute un seul cycle du jeu de la vie. <b>Toutes</bb> les
     * cellules �voluent <b>simultan�ment</b>.
     */
    private void executeOneCycle() {
	// A COMPLETER
    }
}// GameOfLife
