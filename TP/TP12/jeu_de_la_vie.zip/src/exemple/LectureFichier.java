package exemple;


import java.util.*;
import java.io.*;

public class LectureFichier {

    public void lecture(String nomFichier) {
//	try {	    
//	    Scanner scan = new Scanner(new File(nomFichier));
	    // pour pouvoir lire dans  un fichier dans une archive jar :
	    Scanner scan = new Scanner(this.getClass().getResourceAsStream(nomFichier));

	    // ON LIT 2 PREMIERS ENTIERS
	    long premier = scan.nextInt();
	    int second = scan.nextInt();

	    System.out.println(premier+" "+second);

	    // ON REPETE LA LECTURE DE COUPLES D'ENTIER  TANT QU'IL Y EN A
	    while (scan.hasNextInt()) {

		    int x = scan.nextInt();
		try {
		    int y = scan.nextInt();
		    System.out.println("x= "+x+", y="+y);
		} 
		catch(NoSuchElementException e) {
		    System.out.println("manque 'y'");
		}
	    }	    	
	    scan.close();
//	} catch(FileNotFoundException e) {
//	    e.printStackTrace();
//	    System.out.println("fichier "+nomFichier+" non trouve.");
//	}
    }

    public static void main(String[] args) {
	LectureFichier lf = new LectureFichier();
	lf.lecture("test.txt");
	System.out.println("lecture dans 'test.txt' finie");
    }

}
