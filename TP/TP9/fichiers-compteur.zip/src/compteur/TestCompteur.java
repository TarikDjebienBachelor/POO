package compteur;

public class TestCompteur {

    /**
     * Teste le GraphicalCounter avec 3 "Compteur" differents
     */
    public static void main( String[] args ){
	new CompteurGraphique( new CompteurSimple() );
//	new CompteurGraphique( new CompteurModulaire(7) );
//	new CompteurGraphique( new CompteurGeometrique(3) );

	//new CompteurGraphique( LE VOTRE );
    }

}
